#include <stdio.h>
#define read(x) scanf("%d",&x)
#define write(x) printf("%d\n",x)

void foo( ) {
    int a;
    read(a) ;
    write(a) ;
}

int main( ) {
  foo( ) ;
}
