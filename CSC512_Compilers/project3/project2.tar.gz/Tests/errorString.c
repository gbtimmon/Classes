
%m:%~->tcsh

!#/bin/csh

>==

====


